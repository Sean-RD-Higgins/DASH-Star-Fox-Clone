Star Fox Clone
BETA version 0.0.0.1
Created by: Higgins DASH Software

Player 1 Controls:
Movement: Mouse
Fire: Left Click
Left/Right Bearing: A D
Barrel Roll left/right: Q E
Boost/Brake: W S

Player 2 Controls:
Movement: T G F H / Joystick
Fire: M / any gamepad button
Bearing left/right: J L
Barrel Roll left/right: U O
Boost/Brake: I K

Send all bugs/glitches/errors to: http://www.facebook.com/#!/seansuke